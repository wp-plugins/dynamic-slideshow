=== WordPress.com Dynamic Slideshow ===
Donate link: http://xpertshelp.com
Author: Ashok kumar Das
Contributors:
Tested up to: 2.8
Stable tag: 0.5

You can easily set dynamic slide show in your blog

== Installation ==

Installing should be a piece of cake and take fewer than five minutes.

1. Upload the folder "slideshow" to the "wp-content/plugins" directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. From the main menu choose "Options->slideshow" and set width, height, slideshow delay and images".

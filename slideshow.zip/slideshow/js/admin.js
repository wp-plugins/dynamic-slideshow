jQuery(function($){
	$('#tabs').tabs({
		fx: {opacity: 'toggle', duration: 200},
		cookie: {expires: 30}
	});
});